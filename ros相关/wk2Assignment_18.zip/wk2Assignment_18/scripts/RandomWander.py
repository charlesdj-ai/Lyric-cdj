#! /usr/bin/env python

import rospy
import random
from geometry_msgs.msg import Twist
from std_srvs.srv import *

def handle_wander(req):
    res = SetBoolResponse()
    if req.data == True:
        res.success = True
        res.message = 'Random wandering successed!'
        rospy.loginfo('Random wandering on!')
        count = 0
        vel = Twist()

        while count <= 10:
            vel.angular.z = random.uniform(-1, 1)
            vel.linear.x = random.uniform(-1, 1)
            count += 1
            pub_vel.publish(vel)
            rospy.sleep(2)
            rospy.loginfo(count)

        vel.angular.z = 0
        vel.linear.x = 0
        pub_vel.publish(vel)
        
        # rospy.signal_shutdown("Random wandering over!")
        rospy.loginfo("Random wandering over!")
        return res
    else:
        res.success = False
        res.message = 'Random wandering failed!'

if __name__=='__main__':
    rospy.init_node('random_wander')
    pub_vel = rospy.Publisher('wk2Bot18/cmd_vel', Twist, queue_size=1)
    srv = rospy.Service("/random_wander", SetBool, handle_wander)
    rospy.spin()