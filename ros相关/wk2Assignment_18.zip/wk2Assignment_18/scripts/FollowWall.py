#! /usr/bin/env python

import rospy
from sensor_msgs.msg import LaserScan
from geometry_msgs.msg import Twist
from nav_msgs.msg import Odometry
from std_srvs.srv import *
from tf import transformations
from wk2Assignment_18.srv._SetBugBehaviour18 import *

pub_ = None
active_ = False
speed_ = 0.5
turningLeft = True
turningRight = False

# this is a dictionary variable that holds the distances to five directions
regions_ = {
        'right': 0,
        'fright': 0,
        'front': 0,
        'fleft': 0,
        'left': 0,
}

#his variable stores the current state of the robot
state_ = 0

#state_dict_ : this variable holds the possible states
state_dict_ = {
    0: 'find the wall',
    1: 'turn left',
    2: 'follow the wall',
}

def wall_follower_switch(req):
    global active_
    active_ = req.data
    res = SetBoolResponse()
    res.success = True
    res.message = 'Switch!'
    return res

# A partially completed python class used to make the robot follow a wall
class FollowWall:

    def change_state(self, op):
        self.state = op
    def take_action(self, regions):

        state_description = ''
        
        if regions['front'] > 1 and regions['fleft'] > 1 and regions['fright'] > 1:
            state_description = 'case 1 - nothing'
            self.change_state(0)

        elif regions['front'] < 1 and regions['fleft'] > 1 and regions['fright'] > 1:
            state_description = 'case 2 - front'
            self.change_state(1)

        elif regions['front'] > 1 and regions['fleft'] > 1 and regions['fright'] < 1:
            state_description = 'case 3 - fright'
            self.change_state(2)

        elif regions['front'] > 1 and regions['fleft'] < 1 and regions['fright'] > 1:
            state_description = 'case 4 - fleft'
            self.change_state(0)

        elif regions['front'] < 1 and regions['fleft'] > 1 and regions['fright'] < 1:
            state_description = 'case 5 - front and fright'
            self.change_state(1)

        elif regions['front'] < 1 and regions['fleft'] < 1 and regions['fright'] > 1:
            state_description = 'case 6 - front and fleft'
            self.change_state(1)

        elif regions['front'] < 1 and regions['fleft'] < 1 and regions['fright'] < 1:
            state_description = 'case 7 - front and fleft and fright'
            self.change_state(1)

        elif regions['front'] > 1 and regions['fleft'] < 1 and regions['fright'] < 1:
            state_description = 'case 8 - fleft and fright'
            self.change_state(0)

        else:
            state_description = 'unknown case'
            rospy.loginfo(regions)

        rospy.loginfo(state_description)
            
    def callback_laser(self, msg):
        regions = {
            'right':  min(min(msg.ranges[0:143]), 10),
            'fright': min(min(msg.ranges[144:287]), 10),
            'front':  min(min(msg.ranges[288:431]), 10),
            'fleft':  min(min(msg.ranges[432:575]), 10),
            'left':   min(min(msg.ranges[576:713]), 10),
        }
        self.take_action(regions)

    def find_wall(self):
        msg = Twist()
        msg.linear.x = 0.2
        if turningLeft == True:
            msg.angular.z = -0.3
        else:
            msg.angular.z = 0.3
        return msg
    def turn_left(self):
        msg = Twist()
        msg.angular.z = 0.3
        return msg
    def turn_right(self):
        msg = Twist()
        msg.angular.z = -0.3
        return msg
    def follow_the_wall(self):
        msg = Twist()
        msg.linear.x = speed_
        return msg

    def __init__(self):
        # bug0
		# A state machine: 0 - Find the wall; 1 - Turn left; 2 - Follow the wall
        self.state = 0
        
		#Need to change the topic used to command the robot to move based on what you defined in your urdf file.
        self.pub_vel = rospy.Publisher('/wk2Bot18/cmd_vel', Twist, queue_size=1)
		
		#Need to change the topic used for publishing the laser data based on what you defined in your urdf file.
        
        self.sub_laser = rospy.Subscriber('/wk2Bot18/laser/scan', LaserScan, self.callback_laser)
        rate = rospy.Rate(20)
        while not rospy.is_shutdown():
            if not active_:
                rate.sleep()
                continue
        
            msg = Twist()
            if self.state == 0:
                rospy.loginfo('0')
                msg = self.find_wall()
            elif self.state == 1:
                if turningLeft == True:
                    msg = self.turn_left()
                else:
                    msg = self.turn_right()
            elif self.state == 2:
                rospy.loginfo('2')
                msg = self.follow_the_wall()
                pass
            else:
                rospy.logerr('Unknown state!')
            
            self.pub_vel.publish(msg)
            
            rate.sleep()

	# Please complete the rest of code.
	# The overall logic that governs its behavious can be found at 
	# https://www.theconstructsim.com/ros-projects-exploring-ros-using-2-wheeled-robot-part-1/

def handle_set_speed(req):
    global speed_, turningLeft, turningRight
    speed_ = req.speed

    if req.turning == 'left':
        turningLeft = True
        turningRight = False
    else:
        turningLeft = False
        turningRight = True

    res_set_speed_ = SetBugBehaviour18Response()
    res_set_speed_.message = 'Set speed done! (FollowWall.py) \n Set turning done! (FollowWall.py)'
    return res_set_speed_
   
if __name__=='__main__':
    
    rospy.init_node('follow_wall')
    srv_0 = rospy.Service('/set_speed_follow_wall', SetBugBehaviour18, handle_set_speed)
    rsv = rospy.Service('/wall_follower_switch', SetBool, wall_follower_switch)
    FollowWall()
    rospy.spin()