#! /usr/bin/env python

#The code was taken and adapted based on the tutorial available at 
#https://www.theconstructsim.com/ros-projects-exploring-ros-using-2-wheeled-robot-part-1/ 

# import ros stuff
from turtle import speed
import rospy
from sensor_msgs.msg import LaserScan
from geometry_msgs.msg import Twist, Point
from nav_msgs.msg import Odometry
from tf import transformations
from std_srvs.srv import *
from wk2Assignment_18.srv._HomingSignal18 import *
from wk2Assignment_18.srv._SetBugBehaviour18 import *

import math

# File_is_active
active_ = False

# Expected speed
speed_ = 0.5

# robot state variables
position_ = Point()
yaw_ = 0
# machine state
state_ = 0
# goal
desired_position_ = Point()
desired_position_.x = rospy.get_param('des_pos_x')
desired_position_.y = rospy.get_param('des_pos_y')
desired_position_.z = 0
# parameters
yaw_precision_ = math.pi / 90 # +/- 2 degree allowed
dist_precision_ = 0.3

# publishers
pub = None

# callbacks_service
def GoToPoint_switch(req):
    global active_
    active_ = req.data
    res = SetBoolResponse()
    res.success = True
    res.message = 'Switch!'
    return res

# callbacks
def clbk_odom(msg):
    global position_
    global yaw_
    
    # position
    position_ = msg.pose.pose.position
    
    # yaw
    quaternion = (
        msg.pose.pose.orientation.x,
        msg.pose.pose.orientation.y,
        msg.pose.pose.orientation.z,
        msg.pose.pose.orientation.w)
    euler = transformations.euler_from_quaternion(quaternion)
    yaw_ = euler[2]

def change_state(state):
    global state_
    state_ = state
    print('State changed to [%s]' % state_)

def fix_yaw(des_pos):
    global yaw_, pub, yaw_precision_, state_
    desired_yaw = math.atan2(des_pos.y - position_.y, des_pos.x - position_.x)
    err_yaw = desired_yaw - yaw_
    
    twist_msg = Twist()
    if math.fabs(err_yaw) > yaw_precision_:
        twist_msg.angular.z = 0.7 if err_yaw > 0 else -0.7
    
    pub.publish(twist_msg)
    
    # state change conditions
    if math.fabs(err_yaw) <= yaw_precision_:
        print('Yaw error: [%s]' % err_yaw)
        change_state(1)

def go_straight_ahead(des_pos):
    global yaw_, pub, yaw_precision_, state_
    desired_yaw = math.atan2(des_pos.y - position_.y, des_pos.x - position_.x)
    err_yaw = desired_yaw - yaw_
    err_pos = math.sqrt(pow(des_pos.y - position_.y, 2) + pow(des_pos.x - position_.x, 2))
    
    if err_pos > dist_precision_:
        twist_msg = Twist()
        twist_msg.linear.x = speed_
        pub.publish(twist_msg)
    else:
        print('Position error: [%s]' % err_pos)
        change_state(2)
    
    # state change conditions
    if math.fabs(err_yaw) > yaw_precision_:
        print('Yaw error: [%s]' % err_yaw)
        change_state(0)

def done():
    twist_msg = Twist()
    twist_msg.linear.x = 0
    twist_msg.angular.z = 0
    pub.publish(twist_msg)

def main():
    global pub
    
    pub = rospy.Publisher('/wk2Bot18/cmd_vel', Twist, queue_size=1)
    
    sub_odom = rospy.Subscriber('/odom', Odometry, clbk_odom)
    rate = rospy.Rate(20)
    while not rospy.is_shutdown():
        if active_:
            if state_ == 0:
                fix_yaw(desired_position_)
            elif state_ == 1:
                go_straight_ahead(desired_position_)
            elif state_ == 2:
                done()
                pass
            else:
                rospy.logerr('Unknown state!')
                pass
        else:
            continue
        rate.sleep()

def handle_set_goal_point(req):
    global desired_position_
    desired_position_.x = req.des_x
    desired_position_.y = req.des_y
    res_set_goal_point_ = HomingSignal18Response()
    res_set_goal_point_.message = 'Set goal done!'
    return res_set_goal_point_

def handle_set_speed(req):
    global speed_
    speed_ = req.speed
    res_set_speed_ = SetBugBehaviour18Response()
    res_set_speed_.message = 'Set speed done! (GoToPoint.py)'
    return res_set_speed_

if __name__ == '__main__':
    rospy.init_node('go_to_point')
    srv_0 = rospy.Service('/set_speed_go_to_point', SetBugBehaviour18, handle_set_speed)
    srv_1 = rospy.Service('/set_goal_point', HomingSignal18, handle_set_goal_point)
    srv_2 = rospy.Service('/go_to_point_switch', SetBool, GoToPoint_switch)
    main()
    rospy.spin()

# Please complete the rest of code.
# The overall logic that governs its behavious can be found at 
# https://www.theconstructsim.com/ros-projects-exploring-ros-using-2-wheeled-robot-part-1/