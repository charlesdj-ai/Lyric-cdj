#! /usr/bin/env python

import rospy
from wk2Assignment_18.srv._HomingSignal18 import *
from wk2Assignment_18.srv._SetBugBehaviour18 import *
from std_srvs.srv import *

if __name__=='__main__':
    rospy.init_node('center_client')

    # 1. We enable the car move randomly
    rospy.wait_for_service('/random_wander')
    client_random_wander_ = rospy.ServiceProxy('/random_wander', SetBool)
    res_random_wander_ = client_random_wander_.call(True)
    rospy.loginfo(res_random_wander_.message)

    # 2. We need user to input some
    # Part 1 Mainly using HomingSignal service datatype
    # (1) Users input the decision between bug-1 and bug-2
    bug_num = input('Please select the algorithm num you want to implement (1 / 2): ')
    while not (bug_num == 1 or bug_num == 2):
        print('Please type a right value of bug_num!')
        bug_num = input('Please select the algorithm num you want to implement (1 / 2): ')
    # (2) Users input the desired x and desired y
    des_x = input('Your desired x: ')
    des_y = input('Your desired y: ')
    # Part 2 Mainly using SetBugBehaviour service datatype
    # (3) Users input the desired speed of robot to move
    speed = input('The expected speed of robot (only 0.5 or 1.5): ')
    while not (speed == 0.5 or speed == 1.5):
        print('Please type a right value of speed!')
        speed = input('The expected speed of robot (only 0.5 or 1.5): ')
    # (4) Users input the desired orientation of turning when confronted with obstacle
    turning = input('The turning direction on contact with an obstacle (1-left or 2-right): ')
    while not (turning == 1 or turning == 2):
        print('Please type a correct string of turning!')
        turning = input('The turning direction on contact with an obstacle (1-left or 2-right): ')

    if turning == 1:
        turning_way = 'left'
    else:
        turning_way = 'right'

    # 3. The corresponding service is called according to the data entered by the user.
    client_set_goal_point_ = rospy.ServiceProxy('/set_goal_point', HomingSignal18)
    res_set_goal_point_ = client_set_goal_point_.call(True, des_x, des_y, 0)
    rospy.loginfo(res_set_goal_point_.message)
    
    client_set_speed_ = rospy.ServiceProxy('/set_speed_go_to_point', SetBugBehaviour18)
    res_set_speed_ = client_set_speed_.call(True, speed, '0')
    rospy.loginfo(res_set_speed_.message)

    client_set_speed_ = rospy.ServiceProxy('/set_speed_follow_wall', SetBugBehaviour18)
    res_set_speed_ = client_set_speed_.call(True, speed, turning_way)
    rospy.loginfo(res_set_speed_.message)
    # Line 47 - 48 could set speed and turning of FollowWall together

    if bug_num == 1:
        rospy.wait_for_service('/bug1')
        client_bug1_ = rospy.ServiceProxy('/bug1', HomingSignal18)
        res_bug1_ = client_bug1_.call(True, des_x, des_y, 0)
        rospy.loginfo(res_bug1_.message)
    else:
        rospy.wait_for_service('/bug2')
        client_bug2_ = rospy.ServiceProxy('/bug2', HomingSignal18)
        res_bug2_ = client_bug2_.call(True, des_x, des_y, 0)
        rospy.loginfo(res_bug2_.message)